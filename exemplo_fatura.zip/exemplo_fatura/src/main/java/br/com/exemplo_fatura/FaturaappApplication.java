package br.com.exemplo_fatura;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FaturaappApplication {

	public static void main(String[] args) {
		SpringApplication.run(FaturaappApplication.class, args);
	}

}
